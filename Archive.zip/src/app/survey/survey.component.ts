import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import * as Highcharts from 'highcharts';

@Component({
  selector: 'app-survey',
  templateUrl: './survey.component.html',
  styleUrls: ['./survey.component.scss']
})
export class SurveyComponent implements OnInit {


  footPrintForm: FormGroup;
  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: any = {
    series: [
      {
        type: 'column',
        title: {
          text: 'Scores by label'
        },
        data: [],
        xAxis: {
          categories: [
            'electricitiy',
            'flights',
            'transport',
            'food',
            'retail',
          ],
        },
        yAxis: [{ // Primary yAxis
          labels: {
            format: '{value}°C',
            style: {
              color: '#4F81BC',
            }
          },
          title: {
            text: 'Your Score - Units',
            style: {
              color: '#4F81BC'
            }
          },
          opposite: true

        }, { // Secondary yAxis
          gridLineWidth: 0,
          title: {
            text: 'Avg Score - Units',
            style: {
              color: '#C0504E'
            }
          },
          labels: {
            format: '{value} mm',
            style: {
              color: '#C0504E'
            }
          }

        }],
        tooltip: {
          shared: true
        },
      }
    ]
  };
  constructor(private fb: FormBuilder) {
    this.footPrintForm = this.fb.group({
      household: ['' ],
      electricityBill: ['' ],
      noOfFlights: ['' ],
      ownCar: ['' ],
      avgDistance: ['' ],
      publicTrans: ['' ],
      publicShare: ['' ],
      shareTrips: ['' ],
      veg: ['' ],
      noOfMeat: ['' ],
      amountSpent: ['' ],
    });
  }

  ngOnInit(): void {
  }

  calculateCarbonFootPrint(): void{
    const electric = (this.getElectricityBill() / this.getHouseHoldValue()) * 12 / 0.214;
    const flight = this.getNoOfFlights() * 286.88;
    let transportation = 0;
    let food = 0;
    if (this.getNoOfOwnCar().toLowerCase() === 'y' && this.getPublicTrans().toLowerCase() === 'n') {
      transportation = this.getAvgDistance() * 1.61 * 0.435 * 2 * 220;
    } else if (this.getNoOfOwnCar().toLowerCase() === 'y' && this.getPublicTrans().toLowerCase() === 'y') {
      transportation = this.getAvgDistance() * 1.61 * 0.298 * 2 * 220;
    } else if (this.getNoOfOwnCar().toLowerCase() === 'n' && this.getPublicTrans().toLowerCase() === 'y') {
      transportation = this.getAvgDistance() * 1.61 * 0.161 * 2 * 220;
    }
    transportation = transportation + this.getPublicShare() * 61 * 12;
    if (this.getVeg().toLowerCase() === 'y'){
      food = 1542.21406;
    }
    else if (this.getNoOfMeat().toLowerCase() === 'y'){
      food = 2993.70964;
    }
    else{
      food = 2267.96185;
    }
    const retail = 0.1289 * this.getAmountSpent();
    const footPrint = electric + flight + transportation + food + retail;
    const footprintbytype = [electric, flight, transportation, food, retail];
    const footprint_avg = 14660.85;
    const footprintbytype_avg = [7252.76, 602.45, 4515.27, 2267.96, 22.41];
    const labels_footprint = ['electric (kg Co2/year)', 'flight (kg Co2/year)', 'transportation (kg Co2/year)', 'food (kg Co2/year)', 'retail (kg Co2/year)'];
    const labels_footprintbytype = 'total kg Co2/year';
    const footprint_delta = footPrint - footprint_avg;
    let individual_means;
    if (this.getNoOfOwnCar().toLowerCase() === 'y' && this.getPublicTrans().toLowerCase() === 'n'){
      individual_means = [this.getElectricityBill() / 0.1327 * 12 / 1000,
        this.getNoOfFlights(), this.getAvgDistance() * 220 * 2 / 1000, this.getPublicShare() * 12, footprintbytype[3] / 1000];
    }
    else if (this.getNoOfOwnCar().toLowerCase() === 'y' && this.getPublicTrans().toLowerCase() === 'y'){
      individual_means = [ this.getElectricityBill() / 0.1327 * 12 / 1000,
        this.getNoOfFlights(), this.getAvgDistance() * 220 * 2 / 1000, this.getPublicShare() * 12,  footprintbytype[3] / 1000];
    }
    else if (this.getNoOfOwnCar().toLowerCase() === 'n' && this.getPublicTrans().toLowerCase() === 'y'){
      individual_means = [this.getElectricityBill() / 0.1327 * 12 / 1000,
        this.getNoOfFlights(), this.getAvgDistance() * 220 * 2 / 1000, this.getPublicShare() * 12, footprintbytype[3] / 1000];
    }
    else{
      individual_means = [this.getElectricityBill() / 0.1327 * 12 / 1000,
        this.getNoOfFlights(), 0, this.getPublicShare() * 12, footprintbytype[3] / 1000];
    }

   const dataPoints = [
          { label: 'electricitiy', y: 7252.76},
          { label: 'flights', y: 602.45 },
          { label: 'transport', y: 4515.27 },
          { label: 'food', y: 2267.96 },
          { label: 'retail', y: 22.41 }
        ];

    this.chartOptions.series.data = dataPoints;
    // const chart = anychart.bar();
    // chart.data([{
    //   type: 'column',
    //   name: 'Your Score',
    //   showInLegend: true,
    //   yValueFormatString: '#,##0.# Units',
    //   dataPoints: [
    //     { label: 'electricitiy',  y: individual_means[0] },
    //     { label: 'flights', y: individual_means[1] },
    //     { label: 'transport', y: individual_means[2] },
    //     { label: 'food',  y: individual_means[3] },
    //     { label: 'retail',  y: individual_means[4] }
    //   ]
    // },
    //
    //   {
    //     type: 'column',
    //     name: 'Avg Score',
    //     axisYType: 'secondary',
    //     showInLegend: true,
    //     yValueFormatString: '#,##0.# Units',
    //     dataPoints: [
    //       { label: 'electricitiy', y: 7252.76},
    //       { label: 'flights', y: 602.45 },
    //       { label: 'transport', y: 4515.27 },
    //       { label: 'food', y: 2267.96 },
    //       { label: 'retail', y: 22.41 }
    //     ]
    //   }]);
    // chart.title('Scores by label');
    // chart.tooltip(true);
    // chart.xAxis('Kg Co2/Year');




    // const chart =  new anychart.charts.bar('colChartContainer', {
    //   exportEnabled: true,
    //   animationEnabled: true,
    //   title: {
    //     text: 'Scores by label'
    //   },
    //
    //   axisX: {
    //     title: 'Kg Co2/Year'
    //   },
    //   axisY: {
    //     title: 'Your Score - Units',
    //     titleFontColor: '#4F81BC',
    //     lineColor: '#4F81BC',
    //     labelFontColor: '#4F81BC',
    //     tickColor: '#4F81BC',
    //     includeZero: true
    //   },
    //   axisY2: {
    //     title: 'Avg Score - Units',
    //     titleFontColor: '#C0504E',
    //     lineColor: '#C0504E',
    //     labelFontColor: '#C0504E',
    //     tickColor: '#C0504E',
    //     includeZero: true
    //   },
    //   toolTip: {
    //     shared: true
    //   },
    //
    //   data: [{
    //     type: 'column',
    //     name: 'Your Score',
    //     showInLegend: true,
    //     yValueFormatString: '#,##0.# Units',
    //     dataPoints: [
    //       { label: 'electricitiy',  y: individual_means[0] },
    //       { label: 'flights', y: individual_means[1] },
    //       { label: 'transport', y: individual_means[2] },
    //       { label: 'food',  y: individual_means[3] },
    //       { label: 'retail',  y: individual_means[4] }
    //     ]
    //   },
    //
    //     {
    //       type: 'column',
    //       name: 'Avg Score',
    //       axisYType: 'secondary',
    //       showInLegend: true,
    //       yValueFormatString: '#,##0.# Units',
    //       dataPoints: [
    //         { label: 'electricitiy', y: 7252.76},
    //         { label: 'flights', y: 602.45 },
    //         { label: 'transport', y: 4515.27 },
    //         { label: 'food', y: 2267.96 },
    //         { label: 'retail', y: 22.41 }
    //       ]
    //     }]
    // });
  }



  getHouseHoldValue(): number {
    return this.footPrintForm.get('household')?.value;
  }

  getElectricityBill(): number {
    return this.footPrintForm.get('electricityBill')?.value;
  }
  getNoOfFlights(): number {
    return this.footPrintForm.get('noOfFlights')?.value;
  }
  getNoOfOwnCar(): string {
    return this.footPrintForm.get('ownCar')?.value;
  }
  getAvgDistance(): number {
    return this.footPrintForm.get('avgDistance')?.value;
  }

  getPublicTrans(): string {
    return this.footPrintForm.get('publicTrans')?.value;
  }

  getPublicShare(): number {
    return this.footPrintForm.get('publicShare')?.value;
  }

  getVeg(): string {
    return this.footPrintForm.get('veg')?.value;
  }

  getNoOfMeat(): string {
    return this.footPrintForm.get('noOfMeat')?.value;
  }

  getAmountSpent(): number {
    return this.footPrintForm.get('amountSpent')?.value;
  }

}
